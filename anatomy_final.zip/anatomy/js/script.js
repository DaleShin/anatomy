function on1() {
    document.getElementById("heart1").style.display = "block";
}

function off1() {
    document.getElementById("heart1").style.display = "none";
}

function on2() {
    document.getElementById("bloodvesel1").style.display = "block";
}

function off2() {
    document.getElementById("bloodvesel1").style.display = "none";
}

function on3() {
    document.getElementById("bones1").style.display = "block";
}

function off3() {
    document.getElementById("bones1").style.display = "none";
}

function on4() {
    document.getElementById("brain1").style.display = "block";
}

function off4() {
    document.getElementById("brain1").style.display = "none";
}

function on5() {
    document.getElementById("kidneys1").style.display = "block";
}

function off5() {
    document.getElementById("kidneys1").style.display = "none";
}

function on6() {
    document.getElementById("L_interstine_long1").style.display = "block";
}

function off6() {
    document.getElementById("L_interstine_long1").style.display = "none";
}

function on7() {
    document.getElementById("L_interstine_short1").style.display = "block";
}

function off7() {
    document.getElementById("L_interstine_short1").style.display = "none";
}

function on8() {
    document.getElementById("S_interstine1").style.display = "block";
}

function off8() {
    document.getElementById("S_interstine1").style.display = "none";
}

function on9() {
    document.getElementById("lungs1").style.display = "block";
}

function off9() {
    document.getElementById("lungs1").style.display = "none";
}

function on10() {
    document.getElementById("stomach1").style.display = "block";
}

function off10() {
    document.getElementById("stomach1").style.display = "none";
}

function on11() {
    document.getElementById("trachea1").style.display = "block";
}

function off11() {
    document.getElementById("trachea1").style.display = "none";
}

function on12() {
    document.getElementById("brastbone1").style.display = "block";
}

function off12() {
    document.getElementById("brastbone1").style.display = "none";
}

function on13() {
    document.getElementById("liver1").style.display = "block";
}

function off13() {
    document.getElementById("liver1").style.display = "none";
}

// When the user clicks on div, open the popup
function myFunction() {
    var popup = document.getElementById("myPopup");
    popup.classList.toggle("show");
}
function myFunction1() {
    var popup = document.getElementById("myPopup1");
    popup.classList.toggle("show1");
}
function myFunction2() {
    var popup = document.getElementById("myPopup2");
    popup.classList.toggle("show2");
}
function myFunction3() {
    var popup = document.getElementById("myPopup3");
    popup.classList.toggle("show3");
}


  /* Demo purposes only */
  $(".hover").mouseleave(
    function () {
      $(this).removeClass("hover");
    }
  );



















